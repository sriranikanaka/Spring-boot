package Net.javaguides.springboot.service.impl;

import Net.javaguides.springboot.dto.UserDto;
import Net.javaguides.springboot.entity.User;
import Net.javaguides.springboot.mapper.AutoUserMapper;
import Net.javaguides.springboot.repository.UserRepository;
import Net.javaguides.springboot.service.UserService;
import Net.javaguides.springboot.mapper.UserMapper;
import org.modelmapper.ModelMapper;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import java.util.stream.Collectors;



@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    @Override
    public UserDto creatUser(UserDto userDto) {
        // Convert UserDto into user JPA entity
        //User user = modelMapper.map(userDto, User.class);
        User user = AutoUserMapper.MAPPER.mapToUser(userDto);

        User savedUser = userRepository.save(user);
        // Convert user JPA entity to UserDto
        //UserDto savedUserDto = modelMapper.map(savedUser, UserDto.class);
        UserDto savedDto = AutoUserMapper.MAPPER.mapToUserDto(savedUser);
        return modelMapper.map(savedUser,UserDto.class);
    }

    @Override
    public UserDto getUserById(Long userId) {
        Optional<User> optionalUser =userRepository.findById(userId);
        User user =optionalUser.get();
        //return UserMapper.mapToUserDto(user);
        return modelMapper.map(user, UserDto.class);
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepository.findAll();
        //return users.stream()
         //       .map(user -> modelMapper.map(user, UserDto.class))
           //     .collect(Collectors.toList());✅ Collectors.toList()
         return users.stream()
               .map((user)-> AutoUserMapper.MAPPER.mapToUserDto(user))
               .collect(Collectors.toList());
    }

    @Override
    public UserDto updateUser(UserDto user) {
        User existingUser = userRepository.findById(user.getId()).get();
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());
        existingUser.setEmail(user.getEmail());
        //userRepository.save(existingUser);
        User updateUser = userRepository.save(existingUser);
        //return UserMapper.mapToUserDto(updateUser);
        //return modelMapper.map(updateUser, UserDto.class);
        return AutoUserMapper.MAPPER.mapToUserDto(updateUser);
    }

    @Override
    public void deleteUser(Long userId) {
       userRepository.deleteById(userId);
    }


}
