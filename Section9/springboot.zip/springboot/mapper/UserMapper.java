package Net.javaguides.springboot.mapper;

import Net.javaguides.springboot.dto.UserDto;
import Net.javaguides.springboot.entity.User;



public class UserMapper {
    //Convert User JPA Entity into
    public static UserDto mapToUserDto(User user) {
        return new UserDto(
                user.getId(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail()
        );
    }

    // Convert UserDto into User JPA Entity
    public static User mapToUser(UserDto userDto) {
        return new User(
                userDto.getId(),
                userDto.getFirstName(),
                userDto.getLastName(),
                userDto.getEmail()
        );
    }

}

